<pre>
<?php
  
print `/usr/sbin/ifconfig`;

?>
</pre>
